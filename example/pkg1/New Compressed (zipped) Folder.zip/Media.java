


package example.pkg1;

/**
 *
 * @author travi
 */
public class Media
{
    protected String title;
    public Media(String title){
        this.title=title;
    }
    
    public String getTitle(){
        return title;
    }
    
    public void setTitle(String newTitle){
        title=newTitle;
    }
    
}
